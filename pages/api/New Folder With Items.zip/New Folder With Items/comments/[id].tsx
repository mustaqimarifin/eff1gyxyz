import prisma from 'lib/prisma'
import { NextApiRequest, NextApiResponse } from 'next'
import error from 'next/error'
//import { getSession } from 'next-auth/react'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  //const { comment } = req.body;
  const commentId = req.query.id
  const session = await getServerSession(req, res, authOptions)
  //const { id } = session.user;
  if (session && req.method === 'DELETE') {
    await prisma.comment.delete({
      where: {
        id: String(commentId),
      },
    })
    return res.json({ message: 'Comment deleted!' })
  } else {
    res.status(401).send({ message: 'Unauthorized' })
  }
  if (error) {
    throw new Error(
      `The HTTP ${req.method} method is not supported at this route.`
    )
  }
}
